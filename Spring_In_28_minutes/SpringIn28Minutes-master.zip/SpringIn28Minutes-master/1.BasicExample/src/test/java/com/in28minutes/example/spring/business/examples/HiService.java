package com.in28minutes.example.spring.business.examples;

public interface HiService {
	public String sayHi();
}
